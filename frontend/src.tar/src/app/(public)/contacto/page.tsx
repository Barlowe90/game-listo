import { PlaceholderPage } from '@/shared/components/ui/PlaceholderPage';

export default function Home() {
  return (
    <PlaceholderPage
      eyebrow="Contacto"
      title="Zona de contacto con shell consistente"
      description="La pagina hereda el mismo lenguaje visual que el resto del producto: color semantico, espaciado oficial, foco visible y soporte de light y dark mode."
      actions={[
        { href: '/', label: 'Volver al inicio', variant: 'primary' },
        { href: '/registro', label: 'Crear cuenta', variant: 'secondary' },
      ]}
    />
  );
}
