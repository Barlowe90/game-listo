'use client';

import { useSyncExternalStore } from 'react';
import { useTheme } from 'next-themes';
import { cn } from '@/lib/cn';

const options = [
  { value: 'light', label: 'Light' },
  { value: 'dark', label: 'Dark' },
  { value: 'system', label: 'System' },
] as const;

export interface ThemeToggleProps {
  className?: string;
}

function subscribe() {
  return () => {};
}

export function ThemeToggle({ className }: ThemeToggleProps) {
  const { theme, setTheme } = useTheme();
  const mounted = useSyncExternalStore(
    subscribe,
    () => true,
    () => false,
  );

  if (!mounted) {
    return (
      <div
        className={cn(
          'inline-flex min-h-[var(--target-min-size)] items-center rounded-pill border border-border bg-surface p-1 shadow-surface',
          className,
        )}
      >
        <span className="px-3 text-xs font-medium text-muted-foreground">Theme</span>
      </div>
    );
  }

  return (
    <div
      className={cn(
        'inline-flex items-center gap-1 rounded-pill border border-border bg-surface p-1 shadow-surface',
        className,
      )}
      role="group"
      aria-label="Cambiar tema"
    >
      {options.map((option) => {
        const isActive = theme === option.value;

        return (
          <button
            key={option.value}
            type="button"
            onClick={() => setTheme(option.value)}
            className={cn(
              'min-h-[var(--target-min-size)] rounded-pill px-3 py-2 text-xs font-semibold transition-[background-color,color,box-shadow] duration-[var(--duration-fast)] ease-[var(--easing-standard)]',
              isActive
                ? 'bg-primary text-primary-foreground shadow-surface'
                : 'text-secondary hover:bg-background hover:text-foreground',
            )}
            aria-pressed={isActive}
          >
            {option.label}
          </button>
        );
      })}
    </div>
  );
}
